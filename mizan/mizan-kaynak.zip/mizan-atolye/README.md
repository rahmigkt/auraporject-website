# Mizan · Bilim ve Hareket Atölyesi — 0.1

İslam bilim tarihi dijital sergileri için tarayıcıda çalışan matematiksel animasyon ve sahne üretim tezgâhı. Kullanıcının sağladığı dokuz Matharium videosundaki sekiz ayrı içerik ailesi incelenerek geliştirildi. Kaynak videolar veya Matharium kodu ürüne dahil edilmedi.

## Çalıştırma

Python 3 ile proje klasöründe `python -m http.server 8000 --directory dist`, ardından `http://localhost:8000`.

Dosyaya çift tıklamak ES modülleri nedeniyle bazı tarayıcılarda çalışmaz. Sunucu yalnızca statik dosyaları sunar; uygulamanın hesaplama motoru tarayıcıdadır. Kurulumda npm paketi indirmek gerekmez. Three.js 0.186.1 ve MIT lisansı dağıtıma dahildir.

## Kullanım

Soldan sahne, sağdan parametreler seçilir. Oynat/duraklat, zaman kaydırma, başlangıç açısı, hız ve döngü süresi ortak araçlardır. Adımlar yapı taşlarını görünür kılar. Sahne adı ve açıklaması değiştirilebilir. Sergi görünümü editör panellerini gizler. Kayıt tarayıcının localStorage alanındadır; taşınabilir yedek JSON'dur.

π, sol anahtarı ve at sahnelerinde serbest çizim veya dönüşümsüz tek kapalı SVG path içeri alınabilir. Motor tezgâhında 32'ye kadar bağımsız motor eklenebilir. Frekanslar global koordinatlarda tur/döngü; açı derece, yarıçap normalleştirilmiş birimdir. Bu, fiziksel motor sürücüsü değildir.

## Yapı

- `dist/math.js`: DFT, vektör zinciri, örnekleme, korelasyon, integral, analitik alan, veri doğrulama.
- `dist/render.js`: Canvas 2B sahne çizicisi.
- `dist/surface.js`: Three.js 3B sütun ve yüzey çizicisi.
- `dist/scenes.js`: Sahne tanımları, formüller, konturlar ve anlatım adımları.
- `dist/app.js`: zaman çizelgesi, editör, ses, kaydet/yükle, dışa aktarım.
- `dist/vendor`: sürümü sabitlenmiş Three.js ve lisansı.
- `tests/math.test.mjs`: Node standart test sistemi ile matematik kontrolleri.
- `tests/browser-smoke.cjs`: Playwright uçtan uca kontrol senaryosu; ayrı tarayıcı kurulumu gerektirir.

## Doğrulama

`npm test` veya `node --test tests/math.test.mjs`.

Hesaplama testleri; ters DFT yeniden kurulumunu, kesme hatasının monotonluğunu, Tûsî geometrisini, Pearson uç ve tanımsız durumlarını, Riemann toplamının 16/9'a yakınsamasını, alanın analitik türevini, kare çevresini, ses frekanslarını ve içeri alma doğrulamasını kapsar.

## Açık kapsam sınırı

v0.1 bir üretim çekirdeğidir; bütün tarihî aletlerin bitmiş sergisi değildir. Ayrıntılı kapsam ve kabul ölçütleri `dist/TEKNIK-NOTLAR.md` dosyasındadır. Eşzamanlı kullanıcı / bulut arşivi / sunucuda video render / mekanik kısıt çözücüsü bulunmaz. Bu sürümün “arka plan motoru”, tarayıcı içindeki deterministik matematik motorudur; sahte sunucu uçları veya işlenmeyen API çağrıları yoktur.

## Açık kaynak

Three.js: https://github.com/mrdoob/three.js — MIT. Tam lisans `dist/vendor/THREE-LICENSE.txt`.

Manim ve JSXGraph araştırıldı, bağımlılık olarak eklenmedi. Araştırılan projelerin kodları izinsiz kopyalanmadı.

Tarayıcı kontrolünü çalıştırmak için ayrıca Playwright ve onun Chromium kurulumu gerekir. `node tests/browser-smoke.cjs`; isteğe bağlı `MIZAN_TEST_BROWSER` kurulu tarayıcı yolunu, `MIZAN_TEST_OUTPUT` test çıktı klasörünü belirtir. Normal uygulama bunlara bağımlı değildir.
